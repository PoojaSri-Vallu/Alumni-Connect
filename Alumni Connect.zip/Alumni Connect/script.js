document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");

    loginForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        // Static credentials
        const user1 = { email: "user1@gmail.com", password: "123", redirectTo: "homeal.html" };
        const user2 = { email: "user2@gmail.com", password: "456", redirectTo: "sample.html" };

        if (email === user1.email && password === user1.password) {
            window.location.href = user1.redirectTo;
        } else if (email === user2.email && password === user2.password) {
            window.location.href = user2.redirectTo;
        } else {
            alert("Invalid email or password. Please try again.");
        }
    });
});